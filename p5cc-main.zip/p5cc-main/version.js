const VERSION = '3.4';

document.getElementById('version-number').innerHTML = VERSION;


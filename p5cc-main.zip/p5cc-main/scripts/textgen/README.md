# Persona 5 Style Text Generator

Originally made by [@LzxHahaha](https://github.com/LzxHahaha) at [this website](https://lzxhahaha.github.io/persona5/).

Original repository: [LzxHahaha/persona5](https://github.com/LzxHahaha/persona5)

I ported and modified to work with this website.
## 想直接上手用？

简单，点这: [p5.yuluoxk.cn](http://p5.yuluoxk.cn/).

# 女神异闻录5 预告信生成器

生成预告信！

## 使用本地网页搭建

虽然你可以git clone后，打开项目目录并将“index.html”文件拖到浏览器里打开，虽然这么整可能能用，但是在“file://”协议上，一些功能可能会出亿点点小问题。

你可以按照以下步骤快速设置一个正常功能的工具:. 
0. 在您的设备上安装 [NodeJS](https://nodejs.dev) . 
1. 打开您的cmd/终端，并且打开到项目根目录. 
2. 输入 `npm install` 开始安装依赖. 
3. 在终端里输入 `node app.js` 运行项目. 项目将会在 `http://localhost:4200/`运行。.


## Credits

Persona 5 © ATLUS. © SEGA. 

Assets:

- Persona 5 Calling Card Base by Elmind.
- Persona 5 Style Text Generator by @LzxHahaha. Ported and modified by shigukk.
- Persona 5 Logo and Assets by ALTUS.

All assets are all under fair use.

_Credits can also be seen on the website along with links to the original site and owners, at the bottom of the page._


注:本人仅仅做了该项目的汉化以及优化，仓库内容有删改，详细内容请点击上游仓库查看。. 


